@include('includes/header')
<div class='container text-center mt-5' style="width:auto; height:auto;">
    <div class="btn-size">
        <a href="{{ url('task_one') }}"><button class="btn btn-info">Task One</button></a>
        <a href="{{ url('task_two') }}"><button class="btn btn-info">Task two</button></a>
    </div>
    <div>