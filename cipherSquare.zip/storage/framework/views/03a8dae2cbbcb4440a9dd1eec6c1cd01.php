<?php echo $__env->make('includes/header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="container-fluid">
    <div class="row">
        <div class="col-lg-12 mx-auto">
            <div class="card rounded-0 border-0 shadow">
                <div class="card-body p-5">
                    <form id="update_row_data">
                        <div class="table-responsive">
                            <table class="table">
                                <thead>
                                    <tr>
                                        <?php if(!empty($columnCount)): ?>
                                        <?php $__currentLoopData = $columnCount; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <th scope="col"><?php echo e($value); ?></th>
                                        <input type="hidden" id="column_name" name="column_name[]" value="<?php echo e($value); ?>">
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if(!empty($coloumn_two)): ?>
                                    <?php $__currentLoopData = $coloumn_two; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $values): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <input type="hidden" id="row_id" name="row_id[]" value="<?php echo e($values->id); ?>">
                                    <tr>
                                        <?php if(!empty($columnCount)): ?>
                                        <?php $__currentLoopData = $columnCount; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <th><input type="text" class="form-control custom_width" name="row_<?php echo e($values->id); ?>_<?php echo e($value); ?>" value="<?php echo e($values->$value); ?>"></th>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                        <input type="submit" class="btn btn-primary rounded-0 btn-block" value="Update">
                        <a class="btn btn-primary rounded-0 btn-block" onclick="add_coloumn('<?php echo e($finel_count +1); ?>')" style="float:right;">Add New Coloumn</a>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    $(document).on('submit', '#update_row_data', function(ev) {
        ev.preventDefault();
        var formData = new FormData(this);
        $.ajax({
            url: base_url + 'task_two/update',
            type: 'post',
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            },
            data: formData,
            success: function(result) {
                if (result.code == 200) {
                    alert('Data Updated');
                }
            },
            cache: false,
            contentType: false,
            processData: false,

        })
    })
</script><?php /**PATH C:\laravelprojects\ciphersquare_one\resources\views/task_two/index.blade.php ENDPATH**/ ?>