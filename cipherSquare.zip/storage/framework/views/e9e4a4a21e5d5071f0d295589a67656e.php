<?php echo $__env->make('includes/header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class='container text-center mt-5' style="width:auto; height:auto;">
    <div class="btn-size">
        <a href="<?php echo e(url('task_one')); ?>"><button class="btn btn-info">Task One</button></a>
        <a href="<?php echo e(url('task_two')); ?>"><button class="btn btn-info">Task two</button></a>
    </div>
    <div><?php /**PATH C:\laravelprojects\ciphersquare_one\resources\views/Index.blade.php ENDPATH**/ ?>