<?php echo $__env->make('includes/header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="container">
    <div class="row">
        <?php $list_data = Session::get('session_data'); ?>
        <?php if(!empty($list_data)): ?>
        <div class="col-md-12">  
            <div class="form-wrap table-responsive">
                <table class="table table-bordered table-hover">
                    <thead class="thead-dark">
                        <tr>
                            <th scope="col">S.No.</th>
                            <th scope="col">Name</th>
                            <th scope="col">Email</th>
                            <th scope="col">Mobile</th>
                            <th scope="col">Role</th>
                            <th scope="col">Password</th>
                            <th scope="col">Date</th>
                            <th scope="col" colspan="2">Action</th>
                        </tr>
                    </thead>
                    <?php $__currentLoopData = $list_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tbody>
                        <tr>
                            <th scope="row"><?php echo e($key+1); ?></th>
                            <td><?php echo e($value['name']); ?></td>
                            <td><?php echo e($value['email']); ?></td>
                            <td><?php echo e($value['mobile']); ?></td>
                            <td><?php echo e($value['role']); ?></td>
                            <td><?php echo e($value['password']); ?></td>
                            <td><?php echo e($value['date']); ?></td>
                            <td>Edit</td>
                            <td>Delete</td>
                        </tr>
                    </tbody>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </table>
            </div>
        </div>
        <?php endif; ?>
    </div>
</div><?php /**PATH C:\laravelprojects\ciphersquare_one\resources\views/task_one/list.blade.php ENDPATH**/ ?>